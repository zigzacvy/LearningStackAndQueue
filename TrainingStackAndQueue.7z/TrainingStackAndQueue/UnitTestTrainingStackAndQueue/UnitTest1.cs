﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TrainingStackAndQueue;
using Moq;

namespace UnitTestTrainingStackAndQueue
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestQueueStack()
        {
            TrainingStackAndQueue.QueueCustom<int> chk = new QueueCustom<int>();
            chk.Push(6);
            chk.Push(2);
            chk.Push(3);
            chk.Push(4);
            chk.Push(5);
            chk.Push(6);
            Assert.AreEqual(chk.Pop(), 6);
            Assert.AreEqual(chk.Dequeue(), 6);
            Assert.AreEqual(chk.Count, 4);
               

        }

        [TestMethod]
        public void TestQueue()
        {
            TrainingStackAndQueue.QueueCustom<int> queue = new QueueCustom<int>();
            queue.Enqueue(1);
            queue.Enqueue(2);
            queue.Enqueue(3);
            queue.Enqueue(4);
            queue.Enqueue(5);
            queue.Enqueue(6);
            queue.Enqueue(7);
            Assert.AreEqual(queue.Dequeue(), 1);
            Assert.AreEqual(queue.Dequeue(), 2);
            Assert.AreEqual(queue.Pop(), 7);


        }

        [TestMethod]
        public void TestStack()
        {
            TrainingStackAndQueue.StackCustom<int> stack = new StackCustom<int>();
            stack.Push(1);
            stack.Push(2);
            stack.Push(3);
            stack.Push(4);
            stack.Push(5);

            Assert.AreEqual(stack.Pop(), 5);
            
        }
    }
}
