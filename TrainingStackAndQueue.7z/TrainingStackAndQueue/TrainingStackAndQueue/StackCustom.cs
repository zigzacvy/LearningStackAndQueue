﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingStackAndQueue
{
    public class StackCustom<T>:ICustom
    {
        protected T[] arr;
        protected int size;
        public const int INITIAL_CAPACITY = 4;


        public StackCustom(int capacity = INITIAL_CAPACITY)
        {
           
            this.arr = new T[capacity];
            this.size = 0;
            
        }

        public int Count
        {
            get
            {
                return this.size;
            }
        }

        private bool IsEmpty()
        {
            if (this.size == 0)
            {
                return true;
            }
            else
                return false;
        }

        public void Push(T item)
        {
            GrowIfArrIsFull();
            this.arr[this.size] = item;
            this.size++;
        }

        public T Pop()
        {
            if (IsEmpty())
            {
                throw new Exception("Stack OverFlow");
            }
            T item = this.arr[size-1];
            this.arr[this.size-1] = default(T);
            this.size--;
            return item;
        }

        public  void GrowIfArrIsFull()
        {
            if (this.size + 1 > this.arr.Length)
            {
                T[] extendedArr = new T[this.arr.Length +1];
                Array.Copy(this.arr, extendedArr, size);
                this.arr = extendedArr;
            }
        }

        public T this[int index]
        {
            get
            {
                if (index >= this.size || index < 0)
                {
                    throw new ArgumentOutOfRangeException(
                        "Invalid index: " + index);
                }
                return this.arr[index];
            }
            set
            {
                if (index >= this.size || index < 0)
                {
                    throw new ArgumentOutOfRangeException(
                        "Invalid index: " + index);
                }
                this.arr[index] = value;
            }
        }
    }
}
