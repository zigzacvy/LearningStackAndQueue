﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingStackAndQueue
{

    
    public class Program
    {
        static void Main(string[] args)
        {
            QueueCustom<string> queueCustom = new QueueCustom<string>();

            queueCustom.Enqueue("3");
            queueCustom.Enqueue("1");
            queueCustom.Enqueue("1");
            queueCustom.Enqueue("1");
            queueCustom.Enqueue("1");
            queueCustom.Enqueue("1");

            queueCustom.Dequeue();
            Console.ReadLine();
          
         



        }
    }
}
