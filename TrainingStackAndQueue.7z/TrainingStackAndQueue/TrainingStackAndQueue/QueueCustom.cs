﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingStackAndQueue
{
    public class QueueCustom<T> : StackCustom<T>, IQueueCustom<T>
    {
        
        public QueueCustom()
        {
            
        }
        public new int Count
        {
            get
            {
                return base.size;
            }
        }

        public bool IsEmpty
        {
            get
            {
                return (base.size==0);
            }
        }

        public T Dequeue()
        {
            if(this.IsEmpty)
            {
                throw new Exception ("Queue empty");
            }
           
            T first = arr[0];
            for (int i = 0; i < size-1; i++)
            {
                arr[i] = arr[i + 1];
            }
            size--;
            return first;
        }

        public void Enqueue(T item)
        {
            base.GrowIfArrIsFull();
            arr[size] = item;
            size++;
        }

       
    }
}
